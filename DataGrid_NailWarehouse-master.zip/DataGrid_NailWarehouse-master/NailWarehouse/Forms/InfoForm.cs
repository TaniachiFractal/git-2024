﻿using System.Windows.Forms;

namespace NailWarehouse.Forms
{
    /// <summary>
    /// Форма справки
    /// </summary>
    public partial class InfoForm : Form
    {
        /// <summary>
        /// Конструктор формы справки
        /// </summary>
        public InfoForm()
        {
            InitializeComponent();
        }

    }
}
