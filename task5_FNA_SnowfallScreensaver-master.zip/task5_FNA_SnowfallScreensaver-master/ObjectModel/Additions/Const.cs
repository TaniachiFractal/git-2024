﻿namespace SnowfallModels.Additions
{
    /// <summary>
    /// Константы
    /// </summary>
    public class Const
    {
        /// <summary>
        /// Размер снежинки
        /// </summary>
        public const int SnowflakeSize = 32;
    }
}
