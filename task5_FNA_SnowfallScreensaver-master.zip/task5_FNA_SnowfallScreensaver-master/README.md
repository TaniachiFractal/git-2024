### Маслова Т.Д. ИП-21-3 
Скринсейвер "Снегопад" с использованием технологии FNA https://www.youtube.com/watch?v=Ve-ZdOYKV8Q https://fna-xna.github.io/
